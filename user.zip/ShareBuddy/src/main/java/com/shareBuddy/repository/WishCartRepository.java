package com.shareBuddy.repository;

import org.springframework.data.repository.CrudRepository;

import com.shareBuddy.entities.WishCart;

public interface WishCartRepository extends CrudRepository<WishCart, Long> {

}
