package com.shareBuddy.service;

import com.shareBuddy.entities.Message;

public interface MessageService {

	Message save (Message ms);
}
