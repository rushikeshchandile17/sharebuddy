package com.shareBuddy.service;

import com.shareBuddy.entities.WishCart;

public interface WishCartService {
	
	WishCart updateWishCart(WishCart wishCart);
}
